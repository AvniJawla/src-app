export interface Product {
  id: string;
  name: string;
  price: number;
  image: string;
  category: 'men' | 'women';
  type: 'clothing' | 'footwear';
  description: string;
}

export interface Category {
  id: string;
  name: string;
  image: string;
  type: 'men' | 'women';
}