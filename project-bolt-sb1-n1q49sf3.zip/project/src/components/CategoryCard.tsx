import React from 'react';
import type { Category } from '../types';

interface CategoryCardProps {
  category: Category;
}

export function CategoryCard({ category }: CategoryCardProps) {
  return (
    <div className="group relative overflow-hidden rounded-lg">
      <img
        src={category.image}
        alt={category.name}
        className="w-full h-64 object-cover transition-transform duration-300 group-hover:scale-105"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent">
        <div className="absolute bottom-4 left-4">
          <h3 className="text-white text-xl font-semibold">{category.name}</h3>
          <button className="mt-2 text-white hover:text-pink-300 text-sm font-medium">
            Shop Now →
          </button>
        </div>
      </div>
    </div>
  );
}