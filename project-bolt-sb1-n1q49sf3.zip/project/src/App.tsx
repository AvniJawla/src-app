import React from 'react';
import { Navbar } from './components/Navbar';
import { CategoryCard } from './components/CategoryCard';
import { ProductCard } from './components/ProductCard';
import { products } from './data/products';

const categories = [
  {
    id: '1',
    name: "Men's Collection",
    image: 'https://images.unsplash.com/photo-1490578474895-699cd4e2cf59',
    type: 'men'
  },
  {
    id: '2',
    name: "Women's Collection",
    image: 'https://images.unsplash.com/photo-1483985988355-763728e1935b',
    type: 'women'
  }
] as const;

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      {/* Hero Section */}
      <div className="relative">
        <img
          src="https://images.unsplash.com/photo-1441984904996-e0b6ba687e04"
          alt="Fashion Banner"
          className="w-full h-[500px] object-cover"
        />
        <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-4">
              Discover Your Style
            </h1>
            <p className="text-xl text-white mb-8">
              Shop the latest trends in fashion
            </p>
            <button className="bg-white text-gray-900 px-8 py-3 rounded-full font-medium hover:bg-gray-100 transition-colors">
              Shop Now
            </button>
          </div>
        </div>
      </div>

      {/* Categories Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <h2 className="text-2xl font-bold text-gray-900 mb-8">Shop by Category</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {categories.map((category) => (
            <CategoryCard key={category.id} category={category} />
          ))}
        </div>
      </section>

      {/* Featured Products */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <h2 className="text-2xl font-bold text-gray-900 mb-8">Featured Products</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {products.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-lg font-semibold mb-4">About Us</h3>
              <p className="text-gray-400">
                Discover the latest trends in fashion and find your perfect style with our curated collection.
              </p>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-400 hover:text-white">Men's Fashion</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white">Women's Fashion</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white">New Arrivals</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white">Sale</a></li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Contact</h3>
              <ul className="space-y-2 text-gray-400">
                <li>Email: support@fashionhub.com</li>
                <li>Phone: (555) 123-4567</li>
                <li>Address: 123 Fashion Street</li>
              </ul>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;