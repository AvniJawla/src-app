export const products = [
  {
    id: '1',
    name: 'Classic White Shirt',
    price: 49.99,
    image: 'https://images.unsplash.com/photo-1603252109303-2751441dd157',
    category: 'men',
    type: 'clothing',
    description: 'A timeless white cotton shirt perfect for any occasion'
  },
  {
    id: '2',
    name: 'Floral Summer Dress',
    price: 79.99,
    image: 'https://images.unsplash.com/photo-1572804013309-59a88b7e92f1',
    category: 'women',
    type: 'clothing',
    description: 'Light and breezy floral dress for summer days'
  },
  {
    id: '3',
    name: 'Leather Oxford Shoes',
    price: 129.99,
    image: 'https://images.unsplash.com/photo-1449505278894-297fdb3edbc1',
    category: 'men',
    type: 'footwear',
    description: 'Classic leather oxford shoes for formal occasions'
  },
  {
    id: '4',
    name: 'Elegant Heels',
    price: 89.99,
    image: 'https://images.unsplash.com/photo-1543163521-1bf539c55dd2',
    category: 'women',
    type: 'footwear',
    description: 'Sophisticated heels for any formal event'
  }
] as const;